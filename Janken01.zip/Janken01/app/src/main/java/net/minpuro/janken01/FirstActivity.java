package net.minpuro.janken01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener {

    Button button;
    Spinner spinner;

    ArrayAdapter<Integer> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        button = findViewById(R.id.button);
        spinner = findViewById(R.id.spinner);

        button.setOnClickListener(this);

        arrayAdapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item);
        arrayAdapter.add(5);
        arrayAdapter.add(10);
        arrayAdapter.add(20);
        spinner.setAdapter(arrayAdapter);

    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        int selectGames = (int) spinner.getSelectedItem();

        if (id == R.id.button) {
            Intent intent = new Intent(FirstActivity.this, MainActivity.class);
            intent.putExtra("game", selectGames);
            startActivity(intent);
        }

    }
}
