package net.minpuro.janken01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewRemain;
    TextView textViewWin;
    TextView textViewPercent;
    TextView textViewCall;
    TextView textViewCall2;
    ImageView imageViewPartner;
    ImageView imageViewMe;
    TextView textViewJadge;
    TextView textViewAttention;
    Button buttonGu, buttonChoki, buttonPar;
    ImageView imageViewResult;
    Button buttonBack;

    int id;
    Timer timerJ, timerK, timerA;
    Intent intent;
    Bundle bundle;
    int selectGames;
    int numberOfRemain;
    int numberOfWin;
    int numberOfPercent;

    Random random;
    int gamePattern;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewRemain = findViewById(R.id.textViewRemain);
        textViewWin = findViewById(R.id.textViewWin);
        textViewPercent = findViewById(R.id.textViewPercent);
        textViewCall = findViewById(R.id.textViewCall);
        textViewCall2 = findViewById(R.id.textViewCall2);
        imageViewPartner = findViewById(R.id.imageViewPartner);
        imageViewMe = findViewById(R.id.imageViewMe);
        textViewJadge = findViewById(R.id.textViewJadge);
        textViewAttention = findViewById(R.id.textViewAttention);
        buttonGu = findViewById(R.id.buttonGu);
        buttonChoki = findViewById(R.id.buttonChoki);
        buttonPar = findViewById(R.id.buttonPar);
        imageViewResult = findViewById(R.id.imageViewResult);
        buttonBack = findViewById(R.id.buttonBack);

        buttonGu.setOnClickListener(this);
        buttonChoki.setOnClickListener(this);
        buttonPar.setOnClickListener(this);
        buttonBack.setOnClickListener(this);


        intent = getIntent();
        bundle = intent.getExtras();
        selectGames = bundle.getInt("game");

        numberOfRemain = selectGames;
        textViewRemain.setText(String.valueOf(selectGames));

        buttonBack.setEnabled(false);

        callAction();

    }

    public void onResume() {
        super.onResume();
        callAction();
    }

    private void callAction() {
        //「じゃ～～ん、け～ん」とかのコール
        buttonGu.setEnabled(false);
        buttonChoki.setEnabled(false);
        buttonPar.setEnabled(false);

        textViewCall.setText("");
        textViewCall2.setText("");
        textViewAttention.setText("");
        textViewJadge.setText("");
        imageViewPartner.setVisibility(View.INVISIBLE);
        imageViewMe.setVisibility(View.INVISIBLE);
        imageViewResult.setVisibility(View.INVISIBLE);


        timerJ = new Timer();
        TimerTask timerTaskJ = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewCall.setText("じゃ～ん");
                    }
                });
            }
        };
        timerJ.schedule(timerTaskJ, 400);


        timerK = new Timer();
        TimerTask timerTaskK = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewCall2.setText("け～ん");
                    }
                });
            }
        };
        timerK.schedule(timerTaskK, 1500);


        timerA = new Timer();
        TimerTask timerTaskA = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewAttention.setText("※選んで押してください※");
                        buttonGu.setEnabled(true);
                        buttonChoki.setEnabled(true);
                        buttonPar.setEnabled(true);
                    }
                });
            }
        };
        timerA.schedule(timerTaskA, 2300);

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (id == R.id.buttonBack) {
            back();
        } else {
            gameAction();
        }

    }

    private void gameAction() {
        //ボタンを押したとき、ランダムに3パターン出す。
        buttonBack.setEnabled(false);

        imageViewPartner.setVisibility(View.VISIBLE);
        imageViewMe.setVisibility(View.VISIBLE);
        imageViewResult.setVisibility(View.VISIBLE);

        random = new Random();
        gamePattern = random.nextInt(3) + 1;


        switch (gamePattern) {

            case 1:  //「グー」のとき
                imageViewPartner.setImageResource(R.drawable.gu_left_315_315);

                if (id == R.id.buttonGu) {  //グーを選んだら「あいこ」
                    imageViewMe.setImageResource(R.drawable.gu_right_315_315);
                    drawAction();

                } else if (id == R.id. buttonChoki) {  //チョキを選んだら「まけ」
                    imageViewMe.setImageResource(R.drawable.choki_right_315_315);
                    defeatAction();

                } else if (id == R.id.buttonPar) {  //パーを選んだら「かち」
                    imageViewMe.setImageResource(R.drawable.par_right_315_315);
                    winAction();

                }
                break;

            case 2:  //「チョキ」のとき
                imageViewPartner.setImageResource(R.drawable.choki_left_315_315);

                if (id == R.id.buttonGu) {  //グーを選んだら「かち」
                    imageViewMe.setImageResource(R.drawable.gu_right_315_315);
                    winAction();

                } else if (id == R.id. buttonChoki) {  //チョキを選んだら「あいこ」
                    imageViewMe.setImageResource(R.drawable.choki_right_315_315);
                    drawAction();

                } else if (id == R.id.buttonPar) {  //パーを選んだら「まけ」
                    imageViewMe.setImageResource(R.drawable.par_right_315_315);
                    defeatAction();

                }
                break;

            case 3:  //「パー」のとき
                imageViewPartner.setImageResource(R.drawable.par_left_315_315);

                if (id == R.id.buttonGu) {  //グーを選んだら「まけ」
                    imageViewMe.setImageResource(R.drawable.gu_right_315_315);
                    defeatAction();

                } else if (id == R.id. buttonChoki) {  //チョキを選んだら「かち」
                    imageViewMe.setImageResource(R.drawable.choki_right_315_315);
                    winAction();

                } else if (id == R.id.buttonPar) {  //パーを選んだら「あいこ」
                    imageViewMe.setImageResource(R.drawable.par_right_315_315);
                    drawAction();

                }
                break;
        }

    }

    private void drawAction() {
        //あいこのときの処理
        textViewJadge.setText("あいこ！");

        buttonGu.setEnabled(false);
        buttonChoki.setEnabled(false);
        buttonPar.setEnabled(false);

        textViewCall.setText("");
        textViewCall2.setText("");
        textViewAttention.setText("");
        imageViewPartner.setVisibility(View.INVISIBLE);
        imageViewMe.setVisibility(View.INVISIBLE);
        imageViewResult.setVisibility(View.INVISIBLE);

        timerJ.cancel();
        timerK.cancel();
        timerA.cancel();


        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        drawCall();
                    }
                });
            }
        };
        timer.schedule(timerTask, 1000);

//        buttonGu.setEnabled(false);
//        buttonChoki.setEnabled(false);
//        buttonPar.setEnabled(false);
//
//        textViewCall.setText("");
//        textViewCall2.setText("");
//        textViewAttention.setText("");
//
//        imageViewPartner.setVisibility(View.INVISIBLE);
//        imageViewMe.setVisibility(View.INVISIBLE);
//        imageViewResult.setVisibility(View.INVISIBLE);
//
//
//        timerJ.cancel();
//        timerK.cancel();
//        timerA.cancel();
//
//
//        dTimerJ = new Timer();
//        TimerTask dtimerTaskJ = new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        textViewJadge.setText("");
//                        textViewCall.setText("あ～い");
//                    }
//                });
//            }
//        };
//        dTimerJ.schedule(dtimerTaskJ, 400);
//
//
//        dTimerK = new Timer();
//        TimerTask dtimerTaskK = new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        textViewCall2.setText("こで");
//                    }
//                });
//            }
//        };
//        dTimerK.schedule(dtimerTaskK, 1500);
//
//
//        dTimerA = new Timer();
//        TimerTask dtimerTaskA = new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        textViewAttention.setText("※選んで押してください※");
//                        buttonGu.setEnabled(true);
//                        buttonChoki.setEnabled(true);
//                        buttonPar.setEnabled(true);
//
//                    }
//                });
//            }
//        };
//        dTimerA.schedule(dtimerTaskA, 2300);
//
//        gameAction();

    }

    private void drawCall() {
        //「あ～い」「こで」
        textViewJadge.setText("");

        timerJ = new Timer();
        TimerTask timerTaskJ = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewCall.setText("あ～～い");
                    }
                });
            }
        };
        timerJ.schedule(timerTaskJ, 400);


        timerK = new Timer();
        TimerTask timerTaskK = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewCall2.setText("こで");
                    }
                });
            }
        };
        timerK.schedule(timerTaskK, 1500);


        timerA = new Timer();
        TimerTask timerTaskA = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textViewAttention.setText("※選んで押してください※");
                        buttonGu.setEnabled(true);
                        buttonChoki.setEnabled(true);
                        buttonPar.setEnabled(true);
                    }
                });
            }
        };
        timerA.schedule(timerTaskA, 2300);

    }

    private void defeatAction() {
        //まけたとき
        textViewJadge.setText("負け");
        imageViewResult.setImageResource(R.drawable.batsu699403);

        //残り試合数-1
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        if (numberOfRemain == 0) {
            buttonGu.setEnabled(false);
            buttonChoki.setEnabled(false);
            buttonPar.setEnabled(false);

            buttonBack.setEnabled(true);
            textViewJadge.setText("試合終了！");
            textViewCall.setText("");
            textViewCall2.setText("");
            textViewAttention.setText("");

            timerJ.cancel();
            timerK.cancel();
            timerA.cancel();

        } else {
            timerJ.cancel();
            timerK.cancel();
            timerA.cancel();

            Timer timer = new Timer();
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            callAction();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);
        }

        //勝率：(勝ち数 / (選んだ試合数 - 残りの試合数)) * 100
        numberOfPercent = (int) ((double)numberOfWin / (double)(selectGames - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));

    }

    private void winAction() {
        //勝ったとき
        textViewJadge.setText("勝ち！");
        imageViewResult.setImageResource(R.drawable.maru699403);

        //勝ち数+1
        numberOfWin += 1;
        textViewWin.setText(String.valueOf(numberOfWin));

        //残り試合数-1
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        if (numberOfRemain == 0) {
            timerJ.cancel();
            timerK.cancel();
            timerA.cancel();

            buttonGu.setEnabled(false);
            buttonChoki.setEnabled(false);
            buttonPar.setEnabled(false);

            buttonBack.setEnabled(true);
            textViewJadge.setText("試合終了！");
            textViewCall.setText("");
            textViewCall2.setText("");
            textViewAttention.setText("");

        } else {
            timerJ.cancel();
            timerK.cancel();
            timerA.cancel();

            Timer timer = new Timer();
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            callAction();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);
        }

        //勝率：(勝ち数 / (選んだ試合数 - 残りの試合数)) * 100
        numberOfPercent = (int) ((double)numberOfWin / (double)(selectGames - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));

    }

    private void back() {
        finish();
    }
}
